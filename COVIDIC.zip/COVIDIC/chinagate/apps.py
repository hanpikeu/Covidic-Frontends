from django.apps import AppConfig


class ChinagateConfig(AppConfig):
    name = 'chinagate'
